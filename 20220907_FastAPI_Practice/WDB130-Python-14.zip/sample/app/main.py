from fastapi import FastAPI

from .api.routers import programmers


app = FastAPI()

app.include_router(
    programmers.router,
    prefix="/api/programmers",
    tags=["programmers"],
)
