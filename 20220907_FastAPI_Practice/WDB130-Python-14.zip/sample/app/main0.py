"""本文中に最初に掲載した main.py

実行する場合は以下のように実行してください

(venv) $ uvicorn app.main0:app --reload
"""


from fastapi import FastAPI


app = FastAPI()


@app.get("/")
def index():
    return {"message": "Hello World"}
