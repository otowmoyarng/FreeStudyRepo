from fastapi import (
    APIRouter, Depends, HTTPException, Path, status
)
from app.api.dependencies import get_db
from app.api.schemas import (
    ProgrammerListItem, ProgrammerDetail
)
from app.api import cruds


router = APIRouter()


@router.get(
    "/",
    response_model=list[ProgrammerListItem]
)
def list_programmers(
    db=Depends(get_db),
):
    return cruds.get_programmers(db)


@router.get(
    "/{name}",
    response_model=ProgrammerDetail,
    responses={
        status.HTTP_404_NOT_FOUND: {
            "description": "programmer not found",
        }
    }
)
def detail_programmer(
    name: str = Path(max_length=100),
    db=Depends(get_db),
):
    if not cruds.exists_programmer(db, name):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="programmer already exists",
        )
    return cruds.get_programmer_detail_by_name(db, name)


@router.post(
    "/",
    status_code=status.HTTP_201_CREATED,  # 注
    # 注: 紙面にない表記
    # 紙面ではステータスコードを指定せず200を返していましたが、作成後のステータスは201を返したほうがより良いでしょう
    responses={
        status.HTTP_400_BAD_REQUEST: {  # 注
            "description": "programmer already exists",
        }
    }
    # 注: 紙面と異なる表記
    # 紙面では404のように直接数字を示していましたが、fastapiに定数が用意されているので利用したほうが良いでしょう
)
def add_programmer(
    programmer: ProgrammerDetail,
    db=Depends(get_db),
):
    if cruds.exists_programmer(db, programmer.name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="programmer already exists",
        )
    cruds.add_programmer(db, programmer)
    return {"result": "OK"}


@router.put("/{name}")
def update_programmer(
    *,  # 注
    name: str = Path(max_length=100),
    programmer: ProgrammerDetail,
    db=Depends(get_db),
    # 注: 紙面にない説明
    # `update_programmer` は name 引数がデフォルト値を持ち、programmer 引数がデフォルト値を持っていないため
    # そのままでは、Syntaxエラーになってしまいます。このようなケースでは先頭に `*` をつけて、
    # 全てのパラメータをキーワード専用引数にするのがFastAPIではセオリーとなっています。
    # https://fastapi.tiangolo.com/ja/tutorial/path-params-numeric-validations/#order-the-parameters-as-you-need-tricks
):
    cruds.update_programmer(db, name, programmer)
    return {"result": "OK"}


@router.delete(
    "/{name}",
    responses={
        status.HTTP_404_NOT_FOUND: {
            "description": "programmer not found",
        }
    }
)
def delete_programmer(
    name: str,
    db=Depends(get_db),
):
    if not cruds.exists_programmer(db, name):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="programmer already exists",
        )
    cruds.delete_programmer(db, name)
    return {"result": "OK"}
