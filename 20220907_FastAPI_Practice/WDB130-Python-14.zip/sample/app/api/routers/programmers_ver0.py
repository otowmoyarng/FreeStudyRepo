"""サンプルコード routers/programmers.py の最初のバージョン
"""

from fastapi import APIRouter
from app.api.schemas import (
    ProgrammerListItem, ProgrammerDetail
)


router = APIRouter()


@router.get(
    "/",
    response_model=list[ProgrammerListItem]
)
def list_programmers() -> ProgrammerListItem:
    # TODO: 実装:データの検索
    return [
        ProgrammerListItem(name="susumuis"),
        ProgrammerListItem(name="altnight")
    ]


@router.get(
    "/{name}",
    response_model=ProgrammerDetail
)
def detail_programmer(name: str):
    # TODO: 実装:データの取得
    return ProgrammerDetail(
        name="susumuis",
        languages=["Python", "Java", "JavaScript"],
        twitter_id="susumuis"
    )


@router.post("/")
def add_programmer(programmer: ProgrammerDetail):
    # TODO: 実装:データの登録
    return {"result": "OK"}


@router.put("/{name}")
def update_programmer(
    name: str, programmer: ProgrammerDetail
):
    # TODO: 実装:データの更新
    return {"result": "OK"}


@router.delete("/{name}")
def delete_programmer(name: str):
    # TODO: 実装:データの削除
    return {"result": "OK"}
