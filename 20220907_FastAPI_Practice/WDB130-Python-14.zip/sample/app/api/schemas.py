from pydantic import BaseModel, Field


class ProgrammerListItem(BaseModel):
    """一覧用プログラマー情報"""
    name: str

    class Config:
        orm_mode = True


class ProgrammerDetail(BaseModel):
    """プログラマー詳細"""
    name: str
    twitter_id: str
    languages: list[str] = Field(
        ..., min_items=1, max_items=3
    )

    class Config:
        orm_mode = True
