# サンプルコード

## 環境構築

```console
$ python3.10 -m venv venv
$ . venv/bin/activate
(venv) $ pip install -r requirements.txt -c requirements.lock
```

## 動作確認

```console
$ uvicorn app.main:app --reload
```

## 紙面にない表記・紙面と異なる表記

より実践的なサンプルコードとするため、紙面と異なる箇所があります。
ご了承ください。

紙面と異なる箇所には `# 注` と表記し、近くに説明を記載しています。
```py
status_code=status.HTTP_201_CREATED,  # 注
# 注: 紙面にない表記
# 紙面ではステータスコードを指定せず200を返していましたが、作成後のステータスは201を返したほうがより良いでしょう
```

